CHICAGO BEATS BLOODLINE — FL STUDIO 11 PRO HD SKIN ASSET EDIT

This package is based on the FL STUDIO 11 PRO HD asset folder supplied in
FL_Studio_11_skin_promodj.com.zip.

WHAT WAS CUSTOMIZED
- Existing bitmap/PNG interface assets were recolored toward crimson, charcoal,
  and metallic highlights while preserving each asset's original pixel dimensions.
- Peak/audio meter artwork was given a rainbow spectrum treatment.
- AboutPic artwork was replaced with compact CHICAGO BEATS BLOODLINE branding.
- config.txt retains the original Version, sprite positioning, and layout values,
  with title/hint/scope colors updated.
- CHICAGO_BEATS_BLOODLINE_Wallpaper_1920x1080.png is a separate desktop
  wallpaper asset featuring a Chicago night skyline, stars, shooting stars,
  crown, and CHICAGO BEATS title.

IMPORTANT COMPATIBILITY NOTE
FL Studio 11 displays a warning in the original config.txt that skinning is no
longer supported. This is an edited legacy FL Studio 11 skin asset folder, not
a verified installer or a guaranteed fully functional skin. Compatibility must
be tested in the user's exact FL Studio 11 installation. The wallpaper is a
separate image and may need to be set through the desktop/background workflow;
it is not injected into the FL Studio workspace by this legacy skin format.

INSTALLATION (BACK UP FIRST)
1. Close FL Studio 11.
2. Back up the existing FL Studio 11 Data\Patches\Skins folder.
3. Copy the contents of this folder into a new folder under the FL Studio 11
   Skins directory, preserving filenames and subfolders.
4. Reopen FL Studio and check the appearance of the toolbar, mixer, piano roll,
   playlist, and meters.
5. If any controls or sprites render incorrectly, restore the backup.

This package intentionally preserves source image dimensions and sprite
layouts; no executable files or FL Studio program files are included.
