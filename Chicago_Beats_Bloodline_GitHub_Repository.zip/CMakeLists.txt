cmake_minimum_required(VERSION 3.22)
project(ChicagoBeatsBloodline VERSION 0.1.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

include(FetchContent)
FetchContent_Declare(JUCE
  GIT_REPOSITORY https://github.com/juce-framework/JUCE.git
  GIT_TAG 8.0.6
  GIT_SHALLOW TRUE)
FetchContent_MakeAvailable(JUCE)

juce_add_binary_data(BloodlineAssets SOURCES
  assets/batmobile-car-reference.png
  assets/speaker-room-reference.jpg
  assets/bloodline-studio-concept.png)

juce_add_plugin(ChicagoBeatsBloodline
  COMPANY_NAME "Chicago Beats"
  BUNDLE_ID "com.chicagobeats.bloodline"
  PLUGIN_MANUFACTURER_CODE ChBt
  PLUGIN_CODE CbBl
  FORMATS VST3 Standalone
  PRODUCT_NAME "Chicago Beats Bloodline"
  DESCRIPTION "Chicago Beats Bloodline audio-reactive visualizer"
  IS_SYNTH FALSE
  IS_EFFECT TRUE
  NEEDS_MIDI_INPUT TRUE
  NEEDS_MIDI_OUTPUT FALSE
  IS_MIDI_EFFECT FALSE
  EDITOR_WANTS_KEYBOARD_FOCUS FALSE
  COPY_PLUGIN_AFTER_BUILD FALSE)

target_sources(ChicagoBeatsBloodline PRIVATE
  src/plugin/PluginProcessor.cpp
  src/plugin/PluginProcessor.h
  src/plugin/PluginEditor.cpp
  src/plugin/PluginEditor.h)

target_compile_definitions(ChicagoBeatsBloodline PUBLIC
  JUCE_WEB_BROWSER=0
  JUCE_USE_CURL=0
  JUCE_VST3_CAN_REPLACE_VST2=0)

target_link_libraries(ChicagoBeatsBloodline PRIVATE
  BloodlineAssets
  juce::juce_audio_utils
  juce::juce_dsp
  juce::juce_gui_extra
  PUBLIC juce::juce_recommended_config_flags
         juce::juce_recommended_lto_flags
         juce::juce_recommended_warning_flags)
